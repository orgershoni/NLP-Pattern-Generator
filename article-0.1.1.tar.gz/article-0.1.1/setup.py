import setuptools


setuptools.setup(
    name='article',
    version='0.1.1',
    description='Turn your Python script into a report with inline figures.',
    url='http://github.com/danijar/article',
    install_requires=[],
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
    ],
)
